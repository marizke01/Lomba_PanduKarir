<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        @page { size: A4 landscape; margin: 0; }
        html, body { margin: 0; padding: 0; }
        img {
            width: 100%;
            height: 100%;
        }
    </style>
</head>
<body>
    <img src="{{ public_path('images/certificate-bg.jpeg') }}">
</body>
</html>
