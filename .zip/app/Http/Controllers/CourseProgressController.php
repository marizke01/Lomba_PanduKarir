<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CourseProgressController extends Controller
{
    //
}
