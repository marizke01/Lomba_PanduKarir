
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-1">
            <p class="text-[11px] text-slate-500 uppercase tracking-wide">
                Pelatihan Skill
            </p>
            <h2 class="font-semibold text-xl text-gray-900 leading-tight">
                <?php echo e($course['title']); ?>

            </h2>
            <div class="flex flex-wrap items-center gap-2 text-[11px] text-slate-500">
                <span class="px-2 py-0.5 rounded-full bg-slate-100">
                    <?php echo e($course['category']); ?>

                </span>
                <span class="px-2 py-0.5 rounded-full bg-violet-50 text-violet-700">
                    Level: <?php echo e($course['level']); ?>

                </span>
                <span class="px-2 py-0.5 rounded-full bg-slate-100">
                    <?php echo e($course['video_count'] ?? collect($course['modules'] ?? [])->where('type', 'video')->count()); ?> video · <?php echo e($course['duration'] ?? '—'); ?>

                </span>


            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <?php
        // Extra bullet per pelatihan teknologi
        $extraSections = [
            'web-development-dasar' => [
                [
                    'title' => 'Yang akan kamu pelajari',
                    'items' => [
                        'Struktur dasar HTML untuk membangun halaman.',
                        'Mengatur tampilan dengan CSS (warna, font, layout).',
                        'Membuat halaman yang rapi dan responsif.',
                    ],
                ],
                [
                    'title' => 'Cocok untuk siapa?',
                    'items' => [
                        'Siswa SMA/SMK yang baru mulai belajar web.',
                        'Kamu yang ingin punya landasan kuat sebelum ke JavaScript atau Laravel.',
                    ],
                ],
                [
                    'title' => 'Setelah selesai, kamu bisa…',
                    'items' => [
                        'Membuat landing page sederhana sendiri.',
                        'Membaca dan mengedit kode HTML & CSS dengan percaya diri.',
                    ],
                ],
            ],

            'javascript-dasar' => [
                [
                    'title' => 'Yang akan kamu pelajari',
                    'items' => [
                        'Dasar sintaks JavaScript di browser.',
                        'Variabel, tipe data, dan fungsi.',
                        'Event & manipulasi DOM.',
                    ],
                ],
                [
                    'title' => 'Cocok untuk siapa?',
                    'items' => [
                        'Siswa SMA/SMK yang baru mulai ngoding.',
                        'Kamu yang sudah paham HTML & CSS dasar.',
                        'Yang pengin bikin website lebih interaktif.',
                    ],
                ],
                [
                    'title' => 'Setelah selesai, kamu bisa…',
                    'items' => [
                        'Memahami cara kerja JS di browser.',
                        'Membuat interaksi sederhana (tombol, form, dll).',
                        'Membangun mini project seperti To-Do List untuk portofolio.',
                    ],
                ],
            ],

            'mysql-dasar' => [
                [
                    'title' => 'Yang akan kamu pelajari',
                    'items' => [
                        'Konsep dasar database relasional.',
                        'Membuat database & tabel di MySQL.',
                        'Query SELECT, INSERT, UPDATE, dan DELETE.',
                    ],
                ],
                [
                    'title' => 'Cocok untuk siapa?',
                    'items' => [
                        'Siswa SMK RPL / TKJ yang ingin paham backend.',
                        'Kamu yang ingin lanjut ke Laravel / backend web.',
                    ],
                ],
                [
                    'title' => 'Setelah selesai, kamu bisa…',
                    'items' => [
                        'Mendesain tabel sederhana untuk aplikasi.',
                        'Membaca dan menulis query SQL dasar.',
                    ],
                ],
            ],

            'laravel-web-development-pemula' => [
                [
                    'title' => 'Yang akan kamu pelajari',
                    'items' => [
                        'Struktur folder & arsitektur dasar Laravel (MVC).',
                        'Routing, controller, dan Blade template untuk tampilan.',
                        'Migration & Eloquent model untuk mengelola database.',
                        'Membuat fitur CRUD sederhana (Create, Read, Update, Delete).',
                    ],
                ],
                [
                    'title' => 'Cocok untuk siapa?',
                    'items' => [
                        'Siswa SMK/SMA yang sudah mengenal PHP dasar.',
                        'Mahasiswa atau pemula yang ingin pindah dari PHP native ke framework.',
                        'Kamu yang ingin membangun aplikasi web modern dengan cara yang lebih rapi dan terstruktur.',
                    ],
                ],
                [
                    'title' => 'Setelah selesai, kamu bisa…',
                    'items' => [
                        'Membuat aplikasi web sederhana berbasis Laravel (misalnya To-Do App atau Blog).',
                        'Memahami alur request–response & konsep MVC di Laravel.',
                        'Mengembangkan fitur baru dengan percaya diri menggunakan route, controller, dan view.',
                    ],
                ],
            ],
            
        ];

        $sectionsForThisCourse = $extraSections[$course['slug']] ?? null;
    ?>

    <div class="py-6 sm:py-8 bg-slate-50 min-h-screen">
        <div class="max-w-6xl mx-auto sm:px-6 lg:px-8 space-y-6">

            
            <div class="bg-white border border-slate-200 rounded-2xl shadow-sm p-5 space-y-3">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-semibold text-slate-900">
                            Progress pelatihan
                        </p>
                        <p class="text-[11px] text-slate-500">
                            <?php echo e($completedModules); ?> dari <?php echo e($totalModules); ?> modul selesai
                        </p>
                    </div>
                    <p class="text-sm font-semibold text-violet-700">
                        <?php echo e($progressPercent); ?>%
                    </p>
                </div>
                <div class="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div class="h-full bg-violet-500 rounded-full" style="width: <?php echo e($progressPercent); ?>%;"></div>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-5">
                
                <div class="lg:col-span-2 space-y-4">

                    
                    <div class="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
                        
                        
                       <?php
                            $thumb = $course['thumbnail'] ?? '';
                            $thumbFallback = $thumb ? str_replace('maxresdefault','hqdefault',$thumb) : 'https://placehold.co/1200x600?text=SkillBridge';
                        ?>

                        <img
                            src="<?php echo e($thumb ?: $thumbFallback); ?>"
                            onerror="this.onerror=null;this.src='<?php echo e($thumbFallback); ?>';"
                            alt="Thumbnail pelatihan <?php echo e($course['title']); ?>"
                            class="w-full h-full object-contain"
                        />


                        <div class="p-5 space-y-3">
                            <h3 class="text-sm font-semibold text-slate-900">
                                Tentang pelatihan ini
                            </h3>

                            <p class="text-xs text-slate-600">
                                <?php echo e($course['description']); ?>

                            </p>

                            
                            <?php if($sectionsForThisCourse): ?>
                                <div class="grid sm:grid-cols-3 gap-3 text-[11px] text-slate-600 mt-2">
                                    <?php $__currentLoopData = $sectionsForThisCourse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="space-y-1">
                                            <p class="font-semibold text-slate-900">
                                                <?php echo e($section['title']); ?>

                                            </p>
                                            <ul class="list-disc list-inside space-y-0.5">
                                                <?php $__currentLoopData = $section['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($item); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    
                    <div class="bg-white border border-slate-200 rounded-2xl shadow-sm p-5">
                        <div class="flex items-center justify-between mb-3">
                            <h3 class="text-sm font-semibold text-slate-900">
                                Daftar modul
                            </h3>
                            <p class="text-[11px] text-slate-500">
                                Klik modul untuk mulai belajar.
                            </p>
                        </div>

                        <div class="space-y-2">
                            <?php $__currentLoopData = $course['modules']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $prevCompleted = $index === 0
                                        ? true
                                        : optional($progressByModule[$index - 1] ?? null)->is_completed;

                                    $thisCompleted = optional($progressByModule[$index] ?? null)->is_completed;

                                    $isLocked = ! $prevCompleted;
                                ?>

                                <?php if($isLocked): ?>
                                    
                                    <div class="flex items-start justify-between gap-3 px-3 py-2 rounded-xl bg-slate-50 border border-dashed border-slate-200 opacity-70">
                                        <div class="flex items-start gap-3">
                                            <div class="mt-1 h-6 w-6 rounded-full bg-slate-200 text-slate-500 flex items-center justify-center text-[11px]">
                                                <?php echo e($index + 1); ?>

                                            </div>
                                            <div>
                                                <p class="text-xs font-semibold text-slate-500">
                                                    <?php echo e($module['title']); ?>

                                                </p>
                                                <p class="text-[11px] text-slate-400">
                                                    Terkunci · Selesaikan modul sebelumnya dulu
                                                </p>
                                            </div>
                                        </div>
                                        <span class="text-[11px] text-slate-400">
                                            🔒
                                        </span>
                                    </div>
                                <?php else: ?>
                                    
                                    <a href="<?php echo e(route('skills.module', [$course['slug'], $index])); ?>"
                                    class="flex items-start justify-between gap-3 px-3 py-3 rounded-xl hover:bg-slate-50 border border-transparent hover:border-slate-100 transition">
                                        <div class="flex items-start gap-3">
                                            <div class="mt-1 h-6 w-6 rounded-full <?php echo e($thisCompleted ? 'bg-emerald-100 text-emerald-700' : 'bg-violet-100 text-violet-700'); ?> flex items-center justify-center text-[11px]">
                                                <?php echo e($index + 1); ?>

                                            </div>
                                            <div>
                                                <p class="text-xs font-semibold text-slate-900">
                                                    <?php echo e($module['title']); ?>

                                                </p>
                                                <p class="text-[11px] text-slate-500">
                                                    <?php echo e(ucfirst($module['type'])); ?> · <?php echo e($module['duration']); ?>

                                                </p>
                                                <?php if($thisCompleted): ?>
                                                    <p class="text-[11px] text-emerald-600">
                                                        ✅ Modul ini sudah kamu tandai selesai.
                                                    </p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <span class="text-[11px] <?php echo e($thisCompleted ? 'text-emerald-600' : 'text-violet-600'); ?>">
                                            <?php echo e($thisCompleted ? 'Selesai' : 'Buka modul →'); ?>

                                        </span>
                                    </a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>

                
                <div class="space-y-4">
                    <div class="bg-white border border-slate-200 rounded-2xl shadow-sm p-5">
                        <h3 class="text-sm font-semibold text-slate-900 mb-2">
                            Mulai / lanjut belajar
                        </h3>
                        <p class="text-xs text-slate-600 mb-3">
                            Disarankan mulai dari modul pertama, lalu lanjutkan urut sampai project mini di akhir.
                        </p>
                        <form method="POST" action="<?php echo e(route('skills.start', $course['slug'])); ?>">
                            <?php echo csrf_field(); ?>
                            <button
                                class="w-full inline-flex items-center justify-center px-4 py-2 rounded-xl bg-violet-600 text-white text-xs font-medium hover:bg-violet-700">
                                Mulai / lanjut pelatihan
                            </button>
                        </form>
                    </div>

                    <div class="bg-white border border-slate-200 rounded-2xl shadow-sm p-5">
                        <h3 class="text-sm font-semibold text-slate-900 mb-2">
                            Tips belajar efektif
                        </h3>
                        <ul class="list-disc list-inside text-[11px] text-slate-600 space-y-1">
                            <li>Catat poin penting di buku atau note digital.</li>
                            <li>Pause video untuk mencoba sendiri di VS Code / editor.</li>
                            <li>Simpen semua hasil project untuk portofolio.</li>
                        </ul>
                    </div>
                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Lomba_PanduKarir-sertif2\resources\views/skills/show.blade.php ENDPATH**/ ?>