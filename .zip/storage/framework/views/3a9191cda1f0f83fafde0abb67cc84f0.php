<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 flex justify-center bg-gradient-to-br from-slate-100 to-slate-200 min-h-screen">

        <div class="relative bg-white w-[1000px] p-16 rounded-lg shadow-xl overflow-hidden">

            
            <div class="absolute -top-24 -left-24 w-72 h-72 bg-indigo-200/40 rounded-full blur-3xl"></div>
            <div class="absolute -bottom-24 -right-24 w-72 h-72 bg-sky-200/40 rounded-full blur-3xl"></div>

            
            <div class="absolute inset-4 border-4 border-indigo-600 rounded-lg"></div>

            
            <div class="absolute inset-8 border border-indigo-300 rounded-lg"></div>

            
            <div class="relative z-10">

                
                <div class="text-center mb-12">
                    <p class="uppercase tracking-[0.3em] text-xs text-slate-500 mb-3">
                        SkillBridge Certification
                    </p>

                    <h1 class="text-5xl font-extrabold text-slate-900 tracking-wide">
                        Certificate
                    </h1>

                    <div class="flex items-center justify-center gap-3 mt-4">
                        <div class="h-px w-20 bg-indigo-400"></div>
                        <span class="text-sm tracking-widest text-slate-600">
                            of Completion
                        </span>
                        <div class="h-px w-20 bg-indigo-400"></div>
                    </div>
                </div>

                
                <div class="text-center space-y-7">
                    <p class="text-sm text-slate-600">
                        This certificate is proudly presented to
                    </p>

                    <h2 class="text-4xl font-semibold text-indigo-700 tracking-wide">
                        <?php echo e($certificate->user->name); ?>

                    </h2>

                    <div class="max-w-2xl mx-auto">
                        <p class="text-slate-700 leading-relaxed">
                            Telah berhasil menyelesaikan
                            <span class="font-semibold text-slate-900">
                                <?php echo e($certificate->project_title); ?>

                            </span>
                            sebagai bagian dari program pembelajaran dan simulasi
                            project profesional di <span class="font-semibold">SkillBridge</span>.
                        </p>
                    </div>
                </div>

                
                <div class="flex justify-center my-12">
                    <div class="h-[2px] w-40 bg-gradient-to-r from-transparent via-indigo-500 to-transparent"></div>
                </div>

                
                <div class="flex justify-between items-end">
                    <div>
                        <p class="text-xs text-slate-500 uppercase tracking-wide">
                            Issued Date
                        </p>
                        <p class="font-medium text-slate-800">
                            <?php echo e($certificate->issued_at->format('d F Y')); ?>

                        </p>
                    </div>

                    
                    <div class="flex flex-col items-center">
                        <div class="h-14 w-14 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold">
                            SB
                        </div>
                        <p class="text-xs mt-2 text-slate-600 tracking-wide">
                            SkillBridge Certified
                        </p>
                    </div>

                    <div class="text-right">
                        <p class="text-xs text-slate-500 uppercase tracking-wide">
                            Authorized By
                        </p>
                        <p class="font-medium text-slate-800">
                            SkillBridge Platform
                        </p>
                    </div>
                </div>

            </div>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Lomba_PanduKarir-sertif2\resources\views/certificates/show.blade.php ENDPATH**/ ?>