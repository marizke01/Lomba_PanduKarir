
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-1">
            <p class="text-[11px] text-slate-500 uppercase tracking-wide">Belajar Skill</p>
            <h2 class="font-semibold text-xl text-gray-900 leading-tight">Pelatihan SkillBridge</h2>
            <p class="text-xs text-slate-500">
                Pilih pelatihan, ikuti modulnya, kumpulkan tugas, dan bangun portofoliomu.
            </p>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6 sm:py-8 bg-slate-50 min-h-screen">
        <div class="max-w-6xl mx-auto sm:px-6 lg:px-8 space-y-6">

            
            <?php if(!empty($recommended)): ?>
                <?php $firstRec = $recommended[0]; ?>
                <div class="bg-gradient-to-r from-indigo-600 via-indigo-500 to-sky-500 rounded-2xl shadow-lg overflow-hidden">
                    <div class="grid md:grid-cols-2">
                        <div class="p-6 sm:p-7 flex flex-col justify-center gap-3">
                            <p class="text-[11px] text-indigo-100 uppercase tracking-wide">Rekomendasi untukmu</p>
                            <h3 class="text-lg sm:text-xl font-semibold text-white">Mulai dari pelatihan yang kami sarankan</h3>
                            <p class="text-xs text-indigo-100">
                                Pelatihan ini cocok sebagai langkah awal untuk membangun skill dasar sebelum lanjut ke materi yang lebih kompleks.
                            </p>

                            <a href="<?php echo e(route('skills.show', $firstRec['slug'])); ?>"
                               class="inline-flex items-center mt-2 px-4 py-2 rounded-xl bg-white text-xs font-medium text-indigo-700 shadow-sm hover:bg-indigo-50">
                                Lihat pelatihan rekomendasi
                                <svg class="ml-1.5 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none"
                                     viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"
                                          d="M5 12h14M13 6l6 6-6 6"/>
                                </svg>
                            </a>
                        </div>

                        <div class="relative hidden md:block">
                            <div class="absolute inset-0 bg-gradient-to-t from-indigo-900/60 to-transparent z-10"></div>

                            <?php if(!empty($firstRec['thumbnail'])): ?>
                                <img
                                    src="<?php echo e($firstRec['thumbnail']); ?>"
                                    onerror="this.onerror=null;this.src='<?php echo e(str_replace('maxresdefault','hqdefault',$firstRec['thumbnail'])); ?>';"
                                    alt="Thumbnail rekomendasi"
                                    class="h-full w-full object-cover opacity-90"
                                >
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            
            <div class="bg-white border border-slate-200 rounded-2xl shadow-sm p-4 space-y-3">
                <div class="flex flex-wrap items-center justify-between gap-2">
                    <p class="text-xs text-slate-600">Filter pelatihan berdasarkan kategori</p>
                    <a href="<?php echo e(route('skills.index')); ?>" class="text-[11px] text-slate-500 hover:text-indigo-600">
                        Reset filter
                    </a>
                </div>

                <div class="flex flex-wrap gap-2">
                    <a href="<?php echo e(route('skills.index')); ?>"
                       class="px-3 py-1.5 rounded-full border text-[12px]
                        <?php echo e(!$activeCategory ? 'bg-indigo-50 text-indigo-700 border-indigo-100' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'); ?>">
                        Semua
                    </a>

                    <a href="<?php echo e(route('skills.index', ['category' => 'Teknologi'])); ?>"
                       class="px-3 py-1.5 rounded-full border text-[12px]
                        <?php echo e($activeCategory === 'Teknologi' ? 'bg-indigo-50 text-indigo-700 border-indigo-100' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'); ?>">
                        Teknologi
                    </a>

                    <a href="<?php echo e(route('skills.index', ['category' => 'Desain'])); ?>"
                       class="px-3 py-1.5 rounded-full border text-[12px]
                        <?php echo e($activeCategory === 'Desain' ? 'bg-violet-600 text-white border-violet-600' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'); ?>">
                        Desain
                    </a>

                    <a href="<?php echo e(route('skills.index', ['category' => 'Marketing'])); ?>"
                       class="px-3 py-1.5 rounded-full border text-[12px]
                        <?php echo e($activeCategory === 'Marketing' ? 'bg-violet-600 text-white border-violet-600' : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'); ?>">
                        Marketing
                    </a>
                </div>
            </div>

            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e(route('skills.show', $course['slug'])); ?>"
                       class="group bg-white border border-slate-200 rounded-2xl shadow-sm hover:shadow-md transition overflow-hidden flex flex-col">
                        
                        <div class="w-full aspect-[16/9] bg-slate-100 overflow-hidden">
                            <img
                                src="<?php echo e($course['thumbnail'] ?? ''); ?>"
                                onerror="this.onerror=null;this.src='<?php echo e(str_replace('maxresdefault','hqdefault',$course['thumbnail'] ?? '')); ?>';"
                                alt="Thumbnail <?php echo e($course['title']); ?>"
                                class="w-full h-full object-cover object-center group-hover:scale-[1.02] transition duration-300"
                            >
                        </div>

                        <div class="p-4 flex flex-col flex-1">
                            <div class="flex items-center gap-2 mb-2 flex-wrap">
                                <span class="text-[11px] px-2 py-0.5 rounded-full bg-slate-50 text-slate-600 border border-slate-100">
                                    <?php echo e($course['category']); ?>

                                </span>

                                <span class="text-[11px] px-2 py-0.5 rounded-full bg-violet-50 text-violet-700">
                                    <?php echo e($course['level']); ?>

                                </span>

                                
                                <?php if(in_array($course['slug'], $completedCourseSlugs ?? [])): ?>
                                    <span class="text-[11px] px-2 py-0.5 rounded-full
                                                bg-emerald-50 text-emerald-700 border border-emerald-200">
                                        ✓ Sudah dikerjakan
                                    </span>
                                <?php endif; ?>
                            </div>


                            <h3 class="text-sm font-semibold text-slate-900 mb-1 group-hover:text-indigo-700 leading-snug">
                                <?php echo e($course['title']); ?>

                            </h3>
                            <p class="text-[12px] text-slate-500 line-clamp-2 mb-3">
                                <?php echo e($course['description'] ?? 'Pelatihan ini dirancang untuk membangun skill dari dasar.'); ?>

                            </p>

                            <div class="mt-auto flex items-center justify-between text-[11px] text-slate-500 pt-2">
                                <span>
                                    <?php echo e($course['video_count'] ?? collect($course['modules'] ?? [])->where('type','video')->count()); ?>

                                    video · <?php echo e($course['duration'] ?? '—'); ?>

                                </span>
                                <span class="text-indigo-600 font-medium">Lihat detail →</span>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-xs text-slate-500">Belum ada pelatihan dengan filter ini.</p>
                <?php endif; ?>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Lomba_PanduKarir-sertif2\resources\views/skills/index.blade.php ENDPATH**/ ?>